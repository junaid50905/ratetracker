@extends('ui.backend.layouts.default')

@section('title')
    Dashboard
@endsection

@section('main-panel')
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-body">
                    <h2>Dashboard</h2>
                </div>
            </div>
        </div>
    </div>
@endsection
